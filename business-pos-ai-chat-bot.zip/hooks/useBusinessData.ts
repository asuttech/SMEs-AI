
import { useState, useEffect, useCallback } from 'react';
import type { Product, BusinessData, BusinessDataContextType } from '../types';

const LOCAL_STORAGE_KEY = 'businessPosData';

const initialData: BusinessData = {
  businessName: 'My Awesome Business',
  aboutUs: 'We sell amazing things!',
  contactInfo: 'Contact us at contact@awesome.com',
  products: [],
};

export const useBusinessData = (): BusinessDataContextType => {
  const [businessName, setBusinessNameState] = useState<string>('');
  const [aboutUs, setAboutUsState] = useState<string>('');
  const [contactInfo, setContactInfoState] = useState<string>('');
  const [products, setProductsState] = useState<Product[]>([]);
  const [isInitialized, setIsInitialized] = useState<boolean>(false);

  useEffect(() => {
    try {
      const storedData = localStorage.getItem(LOCAL_STORAGE_KEY);
      if (storedData) {
        const parsedData = JSON.parse(storedData) as BusinessData;
        setBusinessNameState(parsedData.businessName || initialData.businessName);
        setAboutUsState(parsedData.aboutUs || initialData.aboutUs);
        setContactInfoState(parsedData.contactInfo || initialData.contactInfo);
        setProductsState(parsedData.products || initialData.products);
      } else {
        setBusinessNameState(initialData.businessName);
        setAboutUsState(initialData.aboutUs);
        setContactInfoState(initialData.contactInfo);
        setProductsState(initialData.products);
      }
    } catch (error) {
      console.error("Failed to load data from localStorage", error);
      setBusinessNameState(initialData.businessName);
      setAboutUsState(initialData.aboutUs);
      setContactInfoState(initialData.contactInfo);
      setProductsState(initialData.products);
    }
    setIsInitialized(true);
  }, []);

  const saveData = useCallback((data: BusinessData) => {
    try {
      localStorage.setItem(LOCAL_STORAGE_KEY, JSON.stringify(data));
    } catch (error) {
      console.error("Failed to save data to localStorage", error);
    }
  }, []);

  useEffect(() => {
    if (isInitialized) {
      saveData({ businessName, aboutUs, contactInfo, products });
    }
  }, [businessName, aboutUs, contactInfo, products, saveData, isInitialized]);

  const addProduct = useCallback((productData: Omit<Product, 'id' | 'imageUrl'>) => {
    const newProduct: Product = {
      ...productData,
      id: Date.now().toString(),
      imageUrl: `https://picsum.photos/seed/${Date.now().toString()}/200/200`,
    };
    setProductsState((prevProducts) => [...prevProducts, newProduct]);
  }, []);

  const removeProduct = useCallback((productId: string) => {
    setProductsState((prevProducts) => prevProducts.filter((p) => p.id !== productId));
  }, []);

  const updateProduct = useCallback((updatedProduct: Product) => {
    setProductsState((prevProducts) =>
      prevProducts.map((p) => (p.id === updatedProduct.id ? updatedProduct : p))
    );
  }, []);

  return {
    businessName,
    setBusinessName: setBusinessNameState,
    aboutUs,
    setAboutUs: setAboutUsState,
    contactInfo,
    setContactInfo: setContactInfoState,
    products,
    addProduct,
    removeProduct,
    updateProduct,
    isInitialized,
  };
};
