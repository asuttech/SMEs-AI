
import { GoogleGenAI, GenerateContentResponse } from "@google/genai";
import type { BusinessData, Product } from '../types';

// Ensure API_KEY is accessed from process.env
// IMPORTANT: This key needs to be set in your environment variables.
// For example, in a .env file (not committed to repo) and loaded by your build process.
const API_KEY = process.env.API_KEY;

if (!API_KEY) {
  console.error("API_KEY for Gemini is not set. Please set process.env.API_KEY.");
  // You could throw an error here or handle it gracefully in the UI
}

const ai = new GoogleGenAI({ apiKey: API_KEY || "MISSING_API_KEY" }); // Fallback to prevent crash if not set, but will fail API calls.

const formatProductsForPrompt = (products: Product[]): string => {
  if (!products || products.length === 0) {
    return "No specific products are currently listed.";
  }
  return products
    .map(
      (p) =>
        `- Name: ${p.name}, Description: ${p.description}, Price: ₦${p.price.toFixed(2)}`
    )
    .join("\n");
};

export const askGemini = async (
  userMessage: string,
  businessData: BusinessData | null
): Promise<string> => {
  if (!API_KEY) {
    return "Gemini API key is not configured. Please contact support.";
  }
  try {
    let systemInstruction = `You are a helpful and friendly AI assistant for a business.`;
    let businessContext = "";

    if (businessData && businessData.businessName) {
       systemInstruction = `You are a helpful and friendly AI assistant for "${businessData.businessName}".`;
       businessContext += `\n\nHere's some information about the business:\n`;
       if (businessData.aboutUs) {
         businessContext += `About Us: ${businessData.aboutUs}\n`;
       }
       if (businessData.contactInfo) {
         businessContext += `Contact Information: ${businessData.contactInfo}\n`;
       }
       if (businessData.products && businessData.products.length > 0) {
         businessContext += `Products:\n${formatProductsForPrompt(businessData.products)}\n`;
       } else {
         businessContext += `No specific products are currently listed for this business.\n`;
       }
    }
    
    const fullPrompt = `${businessContext}\n\nA customer has the following query: "${userMessage}". Please provide a concise, helpful, and polite response. If the query is about products and you have product information, use it. If it's a general query, answer to the best of your ability in a customer-service-oriented manner.`;

    const response: GenerateContentResponse = await ai.models.generateContent({
      model: "gemini-2.5-flash-preview-04-17", // Correct model
      contents: fullPrompt,
      config: {
        systemInstruction: systemInstruction,
        // Not using thinkingConfig: {thinkingBudget:0} to allow default thinking for quality
      }
    });
    
    return response.text;

  } catch (error) {
    console.error("Error calling Gemini API:", error);
    // Check for specific Gemini error types if needed
    if (error instanceof Error) {
        if (error.message.includes("API key not valid")) {
             return "There was an issue with the AI service configuration. Please try again later.";
        }
    }
    return "Sorry, I encountered an error trying to process your request. Please try again later.";
  }
};
