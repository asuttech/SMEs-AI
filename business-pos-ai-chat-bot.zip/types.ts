
export interface Product {
  id: string;
  name: string;
  description: string;
  price: number;
  imageUrl: string;
}

export interface BusinessData {
  businessName: string;
  aboutUs: string;
  contactInfo: string;
  products: Product[];
}

export interface ChatMessage {
  id: string;
  text: string;
  sender: 'user' | 'ai';
  timestamp: Date;
}

// Represents the structure of data managed by useBusinessData hook
export interface BusinessDataContextType extends BusinessData {
  setBusinessName: (name: string) => void;
  setAboutUs: (about: string) => void;
  setContactInfo: (contact: string) => void;
  addProduct: (product: Omit<Product, 'id' | 'imageUrl'>) => void;
  removeProduct: (productId: string) => void;
  updateProduct: (product: Product) => void;
  isInitialized: boolean;
}
