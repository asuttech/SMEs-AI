
import React, { useState, useEffect } from 'react';
import { Navbar } from './components/Navbar';
import { AuthModal } from './components/AuthModal';
import { BusinessAdminDashboard } from './components/BusinessAdminDashboard';
import { ChatWidget } from './components/ChatWidget';
import { useBusinessData } from './hooks/useBusinessData';
import type { BusinessData } from './types';


const App: React.FC = () => {
  const [isAuthModalOpen, setIsAuthModalOpen] = useState(false);
  const [isAuthenticated, setIsAuthenticated] = useState(false); // Vendor logged in
  const [currentView, setCurrentView] = useState<'chat' | 'admin'>('chat');
  
  const businessDataHook = useBusinessData();
  const { businessName, isInitialized } = businessDataHook; // Destructure to get live businessName


  useEffect(() => {
    // Adjust navbar height variable for ChatWidget height calculation
    const navbarElement = document.querySelector('nav');
    if (navbarElement) {
      const navbarHeight = navbarElement.offsetHeight;
      document.documentElement.style.setProperty('--navbar-height', `${navbarHeight}px`);
    }
  }, []);


  const handleAuthClick = () => {
    if (isAuthenticated) {
      // Logout
      setIsAuthenticated(false);
      setCurrentView('chat');
    } else {
      // Open login modal
      setIsAuthModalOpen(true);
    }
  };

  const handleAuthenticationSuccess = () => {
    setIsAuthenticated(true);
    setIsAuthModalOpen(false);
    setCurrentView('admin');
  };

  const handleToggleView = (view: 'chat' | 'admin') => {
    setCurrentView(view);
  };

  if (!isInitialized) {
    return (
      <div className="flex items-center justify-center min-h-screen bg-gray-100">
        <div className="text-xl font-semibold text-slate-700">Loading Business Data...</div>
      </div>
    );
  }

  return (
    <div className="min-h-screen flex flex-col bg-gray-100">
      <Navbar
        isAuthenticated={isAuthenticated}
        onAuthClick={handleAuthClick}
        onToggleView={handleToggleView}
        currentView={currentView}
        businessName={businessName}
      />
      <main className="flex-grow">
        {currentView === 'admin' && isAuthenticated ? (
          <BusinessAdminDashboard businessData={businessDataHook} />
        ) : (
          <ChatWidget businessData={businessDataHook as BusinessData /* Cast needed as hook returns more */} />
        )}
      </main>
      <AuthModal
        isOpen={isAuthModalOpen}
        onClose={() => setIsAuthModalOpen(false)}
        onAuthenticate={handleAuthenticationSuccess}
      />
    </div>
  );
};

export default App;
