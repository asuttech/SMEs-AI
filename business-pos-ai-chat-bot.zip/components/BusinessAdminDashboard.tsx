
import React, { useState } from 'react';
import type { Product, BusinessDataContextType } from '../types';

interface BusinessAdminDashboardProps {
  businessData: BusinessDataContextType;
}

const EditIcon = () => (
  <svg xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24" strokeWidth={1.5} stroke="currentColor" className="w-4 h-4 mr-1">
    <path strokeLinecap="round" strokeLinejoin="round" d="M16.862 4.487l1.687-1.688a1.875 1.875 0 112.652 2.652L10.582 16.07a4.5 4.5 0 01-1.897 1.13L6 18l.8-2.685a4.5 4.5 0 011.13-1.897l8.932-8.931zm0 0L19.5 7.125M18 14v4.75A2.25 2.25 0 0115.75 21H5.25A2.25 2.25 0 013 18.75V8.25A2.25 2.25 0 015.25 6H10" />
  </svg>
);

const TrashIcon = () => (
  <svg xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24" strokeWidth={1.5} stroke="currentColor" className="w-4 h-4 mr-1">
    <path strokeLinecap="round" strokeLinejoin="round" d="M14.74 9l-.346 9m-4.788 0L9.26 9m9.968-3.21c.342.052.682.107 1.022.166m-1.022-.165L18.16 19.673a2.25 2.25 0 01-2.244 2.077H8.084a2.25 2.25 0 01-2.244-2.077L4.772 5.79m14.456 0a48.108 48.108 0 00-3.478-.397m-12.56 0c1.153 0 2.24.086 3.323.251M6.086 5.79l-.614 1.025A2.25 2.25 0 007.71 8.25h8.58a2.25 2.25 0 002.038-1.186l-.614-1.025m-11.952 0A48.107 48.107 0 0112 5.172m-6.538.618A48.108 48.108 0 0112 5.172m6.538.618m0 0V5.192c0-.816-.78-1.486-1.732-1.486H8.732c-.952 0-1.732.67-1.732 1.486v.6" />
  </svg>
);

const ProductCard: React.FC<{ product: Product; onRemove: (id: string) => void; onEdit: (product: Product) => void }> = ({ product, onRemove, onEdit }) => {
  return (
    <div className="bg-white rounded-lg shadow-lg overflow-hidden hover:shadow-xl transition-shadow duration-300">
      <img src={product.imageUrl} alt={product.name} className="w-full h-40 object-cover" />
      <div className="p-4">
        <h3 className="text-lg font-semibold text-slate-800 mb-1">{product.name}</h3>
        <p className="text-sm text-gray-600 mb-2 h-16 overflow-y-auto">{product.description}</p>
        <p className="text-xl font-bold text-sky-600 mb-3">₦{product.price.toFixed(2)}</p>
        <div className="flex space-x-2">
          <button
            onClick={() => onEdit(product)}
            className="flex-1 text-xs inline-flex items-center justify-center px-3 py-1.5 border border-transparent font-medium rounded-md text-sky-700 bg-sky-100 hover:bg-sky-200 transition-colors"
          >
            <EditIcon /> Edit
          </button>
          <button
            onClick={() => onRemove(product.id)}
            className="flex-1 text-xs inline-flex items-center justify-center px-3 py-1.5 border border-transparent font-medium rounded-md text-red-700 bg-red-100 hover:bg-red-200 transition-colors"
          >
            <TrashIcon /> Delete
          </button>
        </div>
      </div>
    </div>
  );
};


export const BusinessAdminDashboard: React.FC<BusinessAdminDashboardProps> = ({ businessData }) => {
  const { businessName, setBusinessName, aboutUs, setAboutUs, contactInfo, setContactInfo, products, addProduct, removeProduct, updateProduct } = businessData;

  const [newProductName, setNewProductName] = useState('');
  const [newProductDescription, setNewProductDescription] = useState('');
  const [newProductPrice, setNewProductPrice] = useState('');
  
  const [editingProduct, setEditingProduct] = useState<Product | null>(null);

  const handleAddOrUpdateProduct = (e: React.FormEvent) => {
    e.preventDefault();
    if (!newProductName.trim() || !newProductPrice.trim()) {
      alert("Product name and price are required.");
      return;
    }
    const price = parseFloat(newProductPrice);
    if (isNaN(price) || price < 0) {
      alert("Please enter a valid price.");
      return;
    }

    if (editingProduct) {
      updateProduct({ ...editingProduct, name: newProductName, description: newProductDescription, price });
      setEditingProduct(null);
    } else {
      addProduct({ name: newProductName, description: newProductDescription, price });
    }
    
    setNewProductName('');
    setNewProductDescription('');
    setNewProductPrice('');
  };
  
  const handleEditProduct = (product: Product) => {
    setEditingProduct(product);
    setNewProductName(product.name);
    setNewProductDescription(product.description);
    setNewProductPrice(product.price.toString());
  };

  const handleCancelEdit = () => {
    setEditingProduct(null);
    setNewProductName('');
    setNewProductDescription('');
    setNewProductPrice('');
  };


  return (
    <div className="container mx-auto p-6 space-y-8">
      <h2 className="text-3xl font-bold text-slate-800 mb-6 border-b pb-3">Vendor Admin Panel</h2>

      {/* Business Information */}
      <section className="bg-white p-6 rounded-xl shadow-lg space-y-6">
        <h3 className="text-xl font-semibold text-slate-700">Business Details</h3>
        <div>
          <label htmlFor="businessName" className="block text-sm font-medium text-gray-700 mb-1">Business Name</label>
          <input
            type="text"
            id="businessName"
            value={businessName}
            onChange={(e) => setBusinessName(e.target.value)}
            className="w-full p-2.5 border border-gray-300 rounded-lg focus:ring-2 focus:ring-sky-500 focus:border-sky-500"
            placeholder="Your Company LLC"
          />
        </div>
        <div>
          <label htmlFor="aboutUs" className="block text-sm font-medium text-gray-700 mb-1">About Us</label>
          <textarea
            id="aboutUs"
            rows={4}
            value={aboutUs}
            onChange={(e) => setAboutUs(e.target.value)}
            className="w-full p-2.5 border border-gray-300 rounded-lg focus:ring-2 focus:ring-sky-500 focus:border-sky-500"
            placeholder="Describe your business..."
          />
        </div>
        <div>
          <label htmlFor="contactInfo" className="block text-sm font-medium text-gray-700 mb-1">Contact Information</label>
          <textarea
            id="contactInfo"
            rows={3}
            value={contactInfo}
            onChange={(e) => setContactInfo(e.target.value)}
            className="w-full p-2.5 border border-gray-300 rounded-lg focus:ring-2 focus:ring-sky-500 focus:border-sky-500"
            placeholder="Email, phone, address..."
          />
        </div>
      </section>

      {/* Product Management */}
      <section className="bg-white p-6 rounded-xl shadow-lg space-y-6">
        <h3 className="text-xl font-semibold text-slate-700">{editingProduct ? 'Edit Product' : 'Add New Product'}</h3>
        <form onSubmit={handleAddOrUpdateProduct} className="space-y-4">
          <div>
            <label htmlFor="productName" className="block text-sm font-medium text-gray-700 mb-1">Product Name</label>
            <input
              type="text"
              id="productName"
              value={newProductName}
              onChange={(e) => setNewProductName(e.target.value)}
              className="w-full p-2.5 border border-gray-300 rounded-lg focus:ring-2 focus:ring-sky-500 focus:border-sky-500"
              placeholder="E.g., Super Laptop X"
              required
            />
          </div>
          <div>
            <label htmlFor="productDescription" className="block text-sm font-medium text-gray-700 mb-1">Description</label>
            <textarea
              id="productDescription"
              rows={3}
              value={newProductDescription}
              onChange={(e) => setNewProductDescription(e.target.value)}
              className="w-full p-2.5 border border-gray-300 rounded-lg focus:ring-2 focus:ring-sky-500 focus:border-sky-500"
              placeholder="Briefly describe the product..."
            />
          </div>
          <div>
            <label htmlFor="productPrice" className="block text-sm font-medium text-gray-700 mb-1">Price (₦)</label>
            <input
              type="number"
              id="productPrice"
              step="0.01"
              value={newProductPrice}
              onChange={(e) => setNewProductPrice(e.target.value)}
              className="w-full p-2.5 border border-gray-300 rounded-lg focus:ring-2 focus:ring-sky-500 focus:border-sky-500"
              placeholder="E.g., 50000.00"
              required
            />
          </div>
          <div className="flex space-x-3">
            <button
              type="submit"
              className="px-6 py-2.5 bg-sky-600 hover:bg-sky-700 text-white font-semibold rounded-lg shadow-md hover:shadow-lg transition-all"
            >
              {editingProduct ? 'Update Product' : 'Add Product'}
            </button>
            {editingProduct && (
                <button
                type="button"
                onClick={handleCancelEdit}
                className="px-6 py-2.5 bg-gray-300 hover:bg-gray-400 text-gray-800 font-semibold rounded-lg shadow-md hover:shadow-lg transition-all"
                >
                Cancel Edit
                </button>
            )}
          </div>
        </form>

        <h3 className="text-xl font-semibold text-slate-700 pt-6 border-t mt-8">Existing Products</h3>
        {products.length === 0 ? (
          <p className="text-gray-500">No products added yet.</p>
        ) : (
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
            {products.map((product) => (
              <ProductCard key={product.id} product={product} onRemove={removeProduct} onEdit={handleEditProduct} />
            ))}
          </div>
        )}
      </section>
    </div>
  );
};
