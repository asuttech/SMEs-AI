
import React, { useState, useRef, useEffect } from 'react';
import type { ChatMessage as ChatMessageType, BusinessData } from '../types'; // Renamed to avoid conflict
import { askGemini } from '../services/geminiService';

interface ChatWidgetProps {
  businessData: BusinessData | null;
}

const PaperAirplaneIcon = () => (
  <svg xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24" strokeWidth={1.5} stroke="currentColor" className="w-5 h-5">
    <path strokeLinecap="round" strokeLinejoin="round" d="M6 12L3.269 3.126A59.768 59.768 0 0121.485 12 59.77 59.77 0 013.27 20.876L5.999 12zm0 0h7.5" />
  </svg>
);

const UserAvatar = () => (
    <div className="w-8 h-8 rounded-full bg-sky-500 flex items-center justify-center text-white text-sm font-semibold">
        U
    </div>
);

const AiAvatar = () => (
    <div className="w-8 h-8 rounded-full bg-slate-700 flex items-center justify-center text-white text-sm font-semibold">
        AI
    </div>
);

const Spinner = () => (
  <svg className="animate-spin h-5 w-5 text-sky-600" xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24">
    <circle className="opacity-25" cx="12" cy="12" r="10" stroke="currentColor" strokeWidth="4"></circle>
    <path className="opacity-75" fill="currentColor" d="M4 12a8 8 0 018-8V0C5.373 0 0 5.373 0 12h4zm2 5.291A7.962 7.962 0 014 12H0c0 3.042 1.135 5.824 3 7.938l3-2.647z"></path>
  </svg>
);


interface ChatMessageItemProps {
  message: ChatMessageType;
}

const ChatMessageItem: React.FC<ChatMessageItemProps> = ({ message }) => {
  const isUser = message.sender === 'user';
  return (
    <div className={`flex items-start space-x-3 mb-4 ${isUser ? 'justify-end' : ''}`}>
      {!isUser && <AiAvatar />}
      <div
        className={`max-w-xs lg:max-w-md px-4 py-3 rounded-xl shadow ${
          isUser
            ? 'bg-sky-500 text-white rounded-br-none'
            : 'bg-white text-gray-800 rounded-bl-none border border-gray-200'
        }`}
      >
        <p className="text-sm whitespace-pre-wrap">{message.text}</p>
        <p className={`text-xs mt-1 ${isUser ? 'text-sky-200 text-right' : 'text-gray-400 text-left'}`}>
          {message.timestamp.toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' })}
        </p>
      </div>
      {isUser && <UserAvatar />}
    </div>
  );
};


export const ChatWidget: React.FC<ChatWidgetProps> = ({ businessData }) => {
  const [messages, setMessages] = useState<ChatMessageType[]>([]);
  const [inputValue, setInputValue] = useState('');
  const [isLoading, setIsLoading] = useState(false);
  const messagesEndRef = useRef<HTMLDivElement>(null);

  useEffect(() => {
    messagesEndRef.current?.scrollIntoView({ behavior: 'smooth' });
  }, [messages]);
  
  useEffect(() => {
    // Initial greeting message from AI
    setMessages([
      {
        id: Date.now().toString(),
        text: `Hello! I am the AI assistant for ${businessData?.businessName || 'this business'}. How can I help you today?`,
        sender: 'ai',
        timestamp: new Date(),
      },
    ]);
  // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [businessData?.businessName]);


  const handleSendMessage = async () => {
    if (inputValue.trim() === '' || isLoading) return;

    const userMessage: ChatMessageType = {
      id: Date.now().toString(),
      text: inputValue,
      sender: 'user',
      timestamp: new Date(),
    };
    setMessages((prevMessages) => [...prevMessages, userMessage]);
    setInputValue('');
    setIsLoading(true);

    try {
      const aiResponseText = await askGemini(userMessage.text, businessData);
      const aiMessage: ChatMessageType = {
        id: (Date.now() + 1).toString(), // Ensure unique ID
        text: aiResponseText,
        sender: 'ai',
        timestamp: new Date(),
      };
      setMessages((prevMessages) => [...prevMessages, aiMessage]);
    } catch (error) {
      console.error('Error sending message or receiving AI response:', error);
      const errorMessage: ChatMessageType = {
        id: (Date.now() + 1).toString(),
        text: "I'm having trouble connecting right now. Please try again in a moment.",
        sender: 'ai',
        timestamp: new Date(),
      };
      setMessages((prevMessages) => [...prevMessages, errorMessage]);
    } finally {
      setIsLoading(false);
    }
  };

  return (
    <div className="flex flex-col h-[calc(100vh-var(--navbar-height,100px))] max-w-3xl mx-auto bg-white shadow-2xl rounded-t-lg overflow-hidden border border-gray-200">
       <div className="p-4 border-b bg-slate-50">
        <h2 className="text-xl font-semibold text-slate-700 text-center">Chat with {businessData?.businessName || 'Us'}</h2>
      </div>
      <div className="flex-grow p-6 space-y-4 overflow-y-auto chat-messages bg-slate-50">
        {messages.map((msg) => (
          <ChatMessageItem key={msg.id} message={msg} />
        ))}
        {isLoading && (
          <div className="flex items-start space-x-3 mb-4">
            <AiAvatar />
            <div className="max-w-xs lg:max-w-md px-4 py-3 rounded-xl shadow bg-white text-gray-800 rounded-bl-none border border-gray-200">
              <div className="flex items-center space-x-2">
                <Spinner /> 
                <span className="text-sm text-gray-500">AI is thinking...</span>
              </div>
            </div>
          </div>
        )}
        <div ref={messagesEndRef} />
      </div>
      <div className="p-4 border-t bg-white">
        <form
          onSubmit={(e) => {
            e.preventDefault();
            handleSendMessage();
          }}
          className="flex items-center space-x-3"
        >
          <input
            type="text"
            value={inputValue}
            onChange={(e) => setInputValue(e.target.value)}
            placeholder="Type your message..."
            className="flex-grow p-3 border border-gray-300 rounded-lg focus:ring-2 focus:ring-sky-500 focus:border-sky-500 transition-shadow"
            disabled={isLoading}
          />
          <button
            type="submit"
            className="p-3 bg-sky-600 text-white rounded-lg hover:bg-sky-700 disabled:bg-gray-400 transition-colors flex items-center justify-center shadow-md hover:shadow-lg"
            disabled={isLoading}
          >
            <PaperAirplaneIcon />
          </button>
        </form>
      </div>
    </div>
  );
};
