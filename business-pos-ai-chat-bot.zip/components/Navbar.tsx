
import React from 'react';

interface NavbarProps {
  isAuthenticated: boolean;
  onAuthClick: () => void;
  onToggleView: (view: 'chat' | 'admin') => void;
  currentView: 'chat' | 'admin';
  businessName: string;
}

const StoreIcon = () => (
  <svg xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24" strokeWidth={1.5} stroke="currentColor" className="w-6 h-6 mr-2">
    <path strokeLinecap="round" strokeLinejoin="round" d="M13.5 21v-7.5A2.25 2.25 0 0011.25 11h-2.5a2.25 2.25 0 00-2.25 2.25V21M3 16.5v2.25A2.25 2.25 0 005.25 21h13.5A2.25 2.25 0 0021 18.75V16.5M16.5 12V8.25A2.25 2.25 0 0014.25 6H5.25A2.25 2.25 0 003 8.25V12m13.5 0h-13.5" />
  </svg>
);


export const Navbar: React.FC<NavbarProps> = ({ isAuthenticated, onAuthClick, onToggleView, currentView, businessName }) => {
  return (
    <nav className="bg-gradient-to-r from-slate-700 to-slate-900 text-white p-4 shadow-lg">
      <div className="container mx-auto flex justify-between items-center">
        <div className="flex items-center text-xl font-semibold">
          <StoreIcon />
          <span>{businessName || 'POS AI ChatBot'}</span>
        </div>
        <div className="space-x-3">
          {isAuthenticated && (
            <button
              onClick={() => onToggleView(currentView === 'chat' ? 'admin' : 'chat')}
              className="px-4 py-2 bg-sky-500 hover:bg-sky-600 rounded-md transition-colors duration-150 text-sm font-medium"
            >
              {currentView === 'chat' ? 'Admin Panel' : 'Chat View'}
            </button>
          )}
          <button
            onClick={onAuthClick}
            className="px-4 py-2 bg-emerald-500 hover:bg-emerald-600 rounded-md transition-colors duration-150 text-sm font-medium"
          >
            {isAuthenticated ? 'Logout' : 'Vendor Login'}
          </button>
        </div>
      </div>
    </nav>
  );
};
